$("#tab5, #tab6, #tab7").tablesorter({
    headers: {
        0: { sorter: false },
        1: { sorter: false }
    },
    widgets: ['indexFirstColumn']
})
